#!/bin/bash

set -euo pipefail

echo "installing python 2..."
sudo apt-get update -y
sudo apt-get install python2
echo "done installing python 2"
